<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >4.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >4.0.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_aurora"></a> [aurora](#module\_aurora) | git::ssh://git@git-ext.ehi.com:7999/cee/terraform-aws-rds-aurora.git | v0.11.5 |
| <a name="module_dms"></a> [dms](#module\_dms) | ./modules/dms | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_route53_record.cluster_endpoint](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.cluster_endpoint_ro](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_zone.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |
| [aws_security_group.db](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/security_group) | data source |
| [aws_subnet.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnet) | data source |
| [aws_subnet_ids.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnet_ids) | data source |
| [aws_vpc.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/vpc) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_deploy_dms"></a> [deploy\_dms](#input\_deploy\_dms) | If true, deploy the DMS module using dms\_targets. If false, do not deploy DMS module.<br>  To produce the panic, set deploy\_dms to true during the initial deployment of this stack.<br>  To avoid the panic, set deploy\_dms to false during the initial deployment. Then, on a second apply,<br>  toggle deploy\_dms to true. | `bool` | n/a | yes |
| <a name="input_endpoint_prefix"></a> [endpoint\_prefix](#input\_endpoint\_prefix) | For naming DMS endpoint resources | `string` | n/a | yes |
| <a name="input_route53_zone"></a> [route53\_zone](#input\_route53\_zone) | Zone for CNAMES, eg pcf-client.ehiaws-sandbox.com | `string` | n/a | yes |
| <a name="input_vpc_name"></a> [vpc\_name](#input\_vpc\_name) | VPC where databases reside | `string` | n/a | yes |
| <a name="input_deploy_roles"></a> [deploy\_roles](#input\_deploy\_roles) | If true, the DMS module will create standard DMS roles required by AWS DMS service. | `bool` | `false` | no |
| <a name="input_dms_targets"></a> [dms\_targets](#input\_dms\_targets) | Defines DMS targets. Example:<br>    dms\_targets = {<br>      "prod\_na" : {<br>        source\_server : "prddblyb.corp.erac.com",<br>        source\_db : "clm1prd.corp.erac.com"<br>      } | `map(any)` | `{}` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Name of environment. | `string` | `"desktop"` | no |
| <a name="input_region"></a> [region](#input\_region) | Region being deployed to. | `string` | `"us-east-1"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_command_line"></a> [command\_line](#output\_command\_line) | Command line to use from jumpbox |
| <a name="output_is_secondary_cluster"></a> [is\_secondary\_cluster](#output\_is\_secondary\_cluster) | Input variable is\_secondary. |
| <a name="output_port"></a> [port](#output\_port) | Port |
| <a name="output_rds_cluster_endpoint"></a> [rds\_cluster\_endpoint](#output\_rds\_cluster\_endpoint) | The cluster endpoint |
| <a name="output_rds_cluster_engine_version"></a> [rds\_cluster\_engine\_version](#output\_rds\_cluster\_engine\_version) | The cluster engine version |
| <a name="output_rds_cluster_reader_endpoint"></a> [rds\_cluster\_reader\_endpoint](#output\_rds\_cluster\_reader\_endpoint) | The cluster reader endpoint |
| <a name="output_rds_security_group_id"></a> [rds\_security\_group\_id](#output\_rds\_security\_group\_id) | The security group ID of the cluster |
| <a name="output_sns_topic_arn"></a> [sns\_topic\_arn](#output\_sns\_topic\_arn) | The ARN of the SNS topic |
<!-- END_TF_DOCS -->